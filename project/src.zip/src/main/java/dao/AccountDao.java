package dao;

public class AccountDao {

}
